# CSS-WARS: THE SELECTOR AWAKENS
A static repo to practice css selectors.

You will be use three types of css selectors in this project:

1. Tag Selector. You will select the h2 tag and turn it #E2E80F. 
    Center the text

2. Class Selector. Select 'credits' class and make it look like links 
    (i.e. underline and colored)

3. Id Selector. Select the 'film-description' ID and make it a smaller 
    font and in italics